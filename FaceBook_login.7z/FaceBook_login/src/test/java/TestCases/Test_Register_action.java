package TestCases;

import java.io.IOException;
import java.util.ArrayList;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;


import pages.FBReg_Page;
import pages.Screenshot_onfailure;
import pages.ExcelReader;

public class Test_Register_action {



	FBReg_Page Registeration;
	ExcelReader testdata;
	ChromeDriver driver =new ChromeDriver();

	@BeforeTest 
	public void open_url()
	{
		
		Registeration =new FBReg_Page(driver);
		testdata = new ExcelReader();
		driver.get("https://www.facebook.com/login.php?next=https%3A%2F%2Fdevelopers.facebook.com%2Fapps");
	}
	
	@Test (priority = 1)
	
	public void login() throws IOException, InterruptedException
	{
		Registeration.Registeration();
		ArrayList<String> credentials = testdata.get_credentials_ofSignup();
		Registeration.enter_signup_data(credentials.get(0), credentials.get(1), credentials.get(2),
				 credentials.get(3),  credentials.get(4),  credentials.get(5),  credentials.get(6)
				 ,  credentials.get(7));	
		  
		Registeration.press_signup();
		 
		String expectedTitle = "Facebook – log in or sign up";
        String originalTitle = driver.getTitle();
        System.out.println(expectedTitle);
        System.out.println(originalTitle);
        Assert.assertEquals(originalTitle, expectedTitle);
	}
	
	@AfterMethod
	
	public void getResult(ITestResult testResult) throws IOException {	 
		Screenshot_onfailure scrshot = new Screenshot_onfailure();
		if (testResult.getStatus() == ITestResult.FAILURE) { 	
			   String filepath = "E:\\test3.png";
				scrshot.takeScreenshot(driver, filepath);
				System.out.println("failed");
		} 
		else if (testResult.getStatus() == ITestResult.SUCCESS)
		{

			System.out.println("success");
		}
	}

	@AfterTest
	public void close_app()
	{
		driver.close();
	}
}
