package TestCases;
import java.io.IOException;
import java.util.ArrayList;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;
import pages.*;

public class Test_login_action {


	FBLogin_page login;
	ExcelReader testdata;
	ChromeDriver driver =new ChromeDriver();

	@BeforeTest 
	public void open_url()
	{
		
		login =new FBLogin_page (driver);
		testdata = new ExcelReader();
		driver.get("https://www.facebook.com/login.php?next=https%3A%2F%2Fdevelopers.facebook.com%2Fapps");
	}
	
	@Test (priority = 0)
	
	public void fblogin() throws IOException, InterruptedException
	{
		ArrayList<String> credentials = testdata.getLoginData();
		login.loginCredentials(credentials.get(0), credentials.get(1));
		login.pressLogin();
		  Thread.sleep(3000);

		String expectedTitle = "Facebook";
        String originalTitle = driver.getTitle();
        Assert.assertEquals(originalTitle, expectedTitle);
	}
	
	@AfterMethod
	public void getResult(ITestResult testResult) throws IOException {	 
		Screenshot_onfailure scrshot = new Screenshot_onfailure();
		if (testResult.getStatus() == ITestResult.FAILURE) { 	
			   String filepath = "E:\\test2.png";
				scrshot.takeScreenshot(driver, filepath);
				String message =  testResult.getName() + "- Test Case Failed";
			//	rep.message_displayed_in_failure(message);
				System.out.println("failed");
		} 
		else if (testResult.getStatus() == ITestResult.SUCCESS)
		{
			String message =  testResult.getName() + "- Test Case Passed";
			//rep.message_displayed_in_passing(message);
			System.out.println("success");
		}
	}
	
	@AfterTest
	public void close_app()
	{
		driver.close();
	}
	
}
