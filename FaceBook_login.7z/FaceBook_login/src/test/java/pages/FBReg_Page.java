package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FBReg_Page {


	@FindBy (id = "u_0_2")
	WebElement register_btn ;

	@FindBy (name = "firstname")
	WebElement first_name ;
	
	@FindBy (name = "lastname")
	WebElement surname ;
	
	@FindBy (name = "reg_email__")
	WebElement mobile_no ;
	
	@FindBy (name = "reg_passwd__")
	WebElement password ;
	
	@FindBy (id = "day")
	WebElement day ;
	
	@FindBy (id = "month")
	WebElement month ;
	
	@FindBy (id = "year")
	WebElement year ;
	
	@FindBy (xpath = "//label[contains(text(),'Female')]")
	WebElement female ;
	
	
	@FindBy (id = "//label[contains(text(),'Male')]")
	WebElement male ;
	
	@FindBy (id = "//label[contains(text(),'Custom')]")
	WebElement custom ;
	
	@FindBy (name = "websubmit")
	WebElement signup ;
	
	
	
	WebDriver driver;
	public FBReg_Page(WebDriver driver) {
		this.driver= driver;
		PageFactory.initElements(driver, this);
	}
	
	public void Registeration()
	{
		register_btn.click();
	}
	
	public void enter_signup_data(String firstname,String Surname ,String mail ,String pass , String day1,
			String month1 , String year1 ,String gender)

			{

		 WebDriverWait wait = new WebDriverWait(driver,10);
		 wait.until(ExpectedConditions.visibilityOf(first_name));    

		 first_name.sendKeys(firstname);
	     surname.sendKeys(Surname);
	     mobile_no.sendKeys(mail);
         password.sendKeys(pass);
         Select s = new Select(day);
         s.selectByValue(day1);
         
         Select s1 = new Select(month);
         s1.selectByValue(month1);
         
         Select s2 = new Select(year);
         s2.selectByValue(year1);
         
		if (gender.equals("female"))
		{
			female.click();
		}
		
		else if (gender.equals("male"))
		{
			male.click();
		}
		
	else 
		custom.click();
	}
	
	public void press_signup ()
	{
		signup.click();
	}
	
}
	


