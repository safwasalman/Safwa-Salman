package pages;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;

public class Screenshot_onfailure {
	public void takeScreenshot (WebDriver driver,String filePath) throws IOException
	{
	TakesScreenshot scrshot = (TakesScreenshot) driver ;
	File src =	scrshot.getScreenshotAs(OutputType.FILE);
	File Dest = new File(filePath);
	FileHandler.copy(src, Dest);
	}
}
