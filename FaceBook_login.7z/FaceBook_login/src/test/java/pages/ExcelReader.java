package pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {
	public ArrayList <String> getLoginData() throws IOException
	{
		File testData = new File("user.dir" + "/src/testdata.xlsx");
		FileInputStream dataFeed = new FileInputStream(testData);
		XSSFWorkbook workbook = new XSSFWorkbook(dataFeed);
		XSSFSheet sheet = workbook.getSheetAt(0);

		Row row = sheet.getRow(2);
		Cell cell = row.getCell(0);
		String email = cell.getStringCellValue();
		System.out.println(email);
		Cell cell2 = row.getCell(1);
		String password = cell2.getStringCellValue();
		System.out.println(password);

		ArrayList<String> credentials =  new ArrayList<String> ();
		credentials.add(email);
		credentials.add(password);

		workbook.close();

		return credentials;
	}
	
	public ArrayList <String> get_credentials_ofSignup() throws IOException
	{
		File testData = new File("user.dir" + "/src/testdata.xlsx");
		FileInputStream dataFeed = new FileInputStream(testData);
		XSSFWorkbook workbook = new XSSFWorkbook(dataFeed);
		XSSFSheet sheet =workbook.getSheetAt(1);
		DataFormatter formatter = new DataFormatter(); 

		Row row2 = sheet.getRow(2);
		Cell cell3 = row2.getCell(0);
		String firstname = cell3.getStringCellValue();
	
		
		Cell cell4 = row2.getCell(1);
		String surname = cell4.getStringCellValue();
		
		
		Cell cell5 = row2.getCell(2);
		String mobile = formatter.formatCellValue(cell5);
		
		
		Cell cell6 = row2.getCell(3);
		String password_reg = cell6.getStringCellValue();
		
		
		Cell cell7 = row2.getCell(4);
		String day = formatter.formatCellValue(cell7);
	
		
		Cell cell8 = row2.getCell(5);
		String month = formatter.formatCellValue(cell8);
	
		
		Cell cell9 = row2.getCell(6);
		String year = formatter.formatCellValue(cell9);
	
		
		Cell cell0 = row2.getCell(7);
		String gender = cell0.getStringCellValue();
		
		
		ArrayList<String> signUpData =  new ArrayList<String> ();
		signUpData.add(firstname);
		signUpData.add(surname);
		signUpData.add(mobile);
		signUpData.add(password_reg);
		signUpData.add(day);
		signUpData.add(month);
		signUpData.add(year);
		signUpData.add(gender);
		return signUpData;
	}
	}

