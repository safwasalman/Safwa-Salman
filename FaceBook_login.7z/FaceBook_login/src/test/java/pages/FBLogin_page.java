package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public  class FBLogin_page {

	WebDriver driver;
	@FindBy (id = "email")
	WebElement email_textbox ;
	
	@FindBy (id = "pass")
	WebElement password_textbox ;
	
	@FindBy (id = "u_0_b")
	WebElement login_btn ;
	
	public FBLogin_page(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void loginCredentials(String mail , String password)
	{
		email_textbox.sendKeys(mail);
		password_textbox.sendKeys(password);
	}	
	public void pressLogin()
	{
		login_btn.click();
	}
	
}
